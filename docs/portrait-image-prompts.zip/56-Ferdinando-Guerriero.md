Create exactly one NEW original ultra-photorealistic studio media-day portrait of a fictional young male footballer, approximately 21–25 years old. This is a new image generated solely from the following written visual description.

IMMUTABLE CANONICAL FACIAL DESCRIPTION: faithfully reproduce EACH listed feature, especially skin complexion, hair color, hair texture, hair length and exact compatible haircut:
FACE SHAPE: asymmetric oval face. CHEEKS: broad lower cheeks. FOREHEAD: ordinary forehead height.
EYES: brown eyes, gently hooded eyelids, ordinary eye spacing. BROWS: softly arched eyebrows.
NOSE: straight unremarkable nasal bridge, soft downturned nose tip. JAW: soft unsculpted jawline. CHIN: broad but soft chin.
MOUTH: one lip corner subtly lower, uneven natural lip contour. EARS: ordinary ears.
COMPLEXION: light warm complexion. FACIAL HAIR: clean shaven.
HAIR: very short length; light brown color; tight curly texture; very short practical curly haircut; ordinary natural density; ordinary hairline.
SKIN: slightly uneven skin tone; no conspicuous facial mark.

PHYSIQUE: average-fit; an ordinary proportionate torso with a naturally soft waist. This must remain consistent with the frozen initial strength/speed/agility body class, not position or stereotypes. Stamina cannot inflate muscle definition. Ordinary human body softness is welcome; no bodybuilder build, etched abs, sculpted deltoids or oversized biceps.

Look like an ordinary real young male, approximately 21–25 years old, chosen for footballing ability rather than looks. Preserve natural asymmetry, non-idealized facial proportions, visible natural skin texture and small imperfections. No beauty retouching, glamorous styling, perfect symmetry, waxy pores, fashion-model faces or advertising lighting.

Exactly one subject standing front-facing with level shoulders, direct gaze, neutral mouth and arms hanging naturally at his sides. Show all hair, complete head, shoulders, both arms, torso and waist DOWN TO HIP LEVEL. Do not show additional people, body doubles, captions, labels, player numbers or a collage.

Plain PURE WHITE short-sleeved REGULAR-FIT football jersey, unbranded, comfortably draped with subtle folds; never skin-tight or body-sculpting. No logo, sponsor, number, text, color trim, props or accessories.

Source image vertical 3:4 with native genuine TRANSPARENT RGBA PNG alpha; background outside the subject must be fully alpha=0, NOT a printed checkerboard, gray backdrop or artificial transparency pattern. Clean naturally antialiased edges without chromatic halo or matte contamination.

Maintain the described facial details precisely. One person only. Photographic realism, natural soft lighting, direct camera gaze, full hair and head through hip level. No typography, graphics or collage.
