Create exactly one NEW original ultra-photorealistic studio media-day portrait of a fictional adult male footballer. This is a new image generated solely from the following written visual description.

IMMUTABLE CANONICAL FACIAL DESCRIPTION: faithfully reproduce EACH listed feature, especially skin complexion, hair color, hair texture, hair length and exact compatible haircut:
FACE SHAPE: soft square face. CHEEKS: asymmetrically full cheeks. FOREHEAD: ordinary forehead height.
EYES: dark brown eyes, softly downturned outer corners, slightly wide-set eyes. BROWS: softly arched eyebrows.
NOSE: subtle asymmetry in the nasal bridge, moderately broad nose tip. JAW: narrow ordinary jawline. CHIN: slightly asymmetric chin.
MOUTH: one lip corner subtly lower, rather thin lips. EARS: slightly asymmetrical ear size.
COMPLEXION: medium golden-brown complexion. FACIAL HAIR: faint uneven stubble.
HAIR: medium length; dark brown color; wavy texture; medium wavy unstyled haircut; ordinary natural density; slightly higher temples.
SKIN: natural visible skin texture and pores; no conspicuous facial mark.

PHYSIQUE: average-fit; average shoulders and arms without visible muscle sculpting. This must remain consistent with the frozen initial strength/speed/agility body class, not position or stereotypes. Stamina cannot inflate muscle definition. Ordinary human body softness is welcome; no bodybuilder build, etched abs, sculpted deltoids or oversized biceps.

Look like an ordinary real adult male, chosen for footballing ability rather than looks. Preserve natural asymmetry, non-idealized facial proportions, visible natural skin texture and small imperfections. No beauty retouching, glamorous styling, perfect symmetry, waxy pores, fashion-model faces or advertising lighting.

Exactly one subject standing front-facing with level shoulders, direct gaze, neutral mouth and arms hanging naturally at his sides. Show all hair, complete head, shoulders, both arms, torso and waist DOWN TO HIP LEVEL. Do not show additional people, body doubles, captions, labels, player numbers or a collage.

Plain PURE WHITE short-sleeved REGULAR-FIT football jersey, unbranded, comfortably draped with subtle folds; never skin-tight or body-sculpting. No logo, sponsor, number, text, color trim, props or accessories.

Source image vertical 3:4 with native genuine TRANSPARENT RGBA PNG alpha; background outside the subject must be fully alpha=0, NOT a printed checkerboard, gray backdrop or artificial transparency pattern. Clean naturally antialiased edges without chromatic halo or matte contamination.

Maintain the described facial details precisely. One person only. Photographic realism, natural soft lighting, direct camera gaze, full hair and head through hip level. No typography, graphics or collage.
