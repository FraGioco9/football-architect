Create exactly one NEW original ultra-photorealistic studio media-day portrait of a fictional adult male footballer. This is a new image generated solely from the following written visual description.

IMMUTABLE CANONICAL FACIAL DESCRIPTION: faithfully reproduce EACH listed feature, especially skin complexion, hair color, hair texture, hair length and exact compatible haircut:
FACE SHAPE: asymmetric oval face. CHEEKS: gently fuller cheeks. FOREHEAD: ordinary forehead height.
EYES: amber-brown eyes, gently hooded eyelids, moderately wide-set eyes. BROWS: slightly unequal eyebrows.
NOSE: prominent natural bridge, soft downturned nose tip. JAW: subtly asymmetric jawline. CHIN: ordinary rounded chin.
MOUTH: ordinary relaxed mouth width, uneven natural lip contour. EARS: ordinary ears.
COMPLEXION: light warm complexion. FACIAL HAIR: faint uneven stubble.
HAIR: medium length; copper red color; wavy texture; medium slightly grown-out waves; mildly thin hair; ordinary hairline.
SKIN: natural visible skin texture and pores; small natural facial mole.

PHYSIQUE: lean-fit; slender, gently conditioned shoulders and unremarkable arms. This must remain consistent with the frozen initial strength/speed/agility body class, not position or stereotypes. Stamina cannot inflate muscle definition. Ordinary human body softness is welcome; no bodybuilder build, etched abs, sculpted deltoids or oversized biceps.

Look like an ordinary real adult male, chosen for footballing ability rather than looks. Preserve natural asymmetry, non-idealized facial proportions, visible natural skin texture and small imperfections. No beauty retouching, glamorous styling, perfect symmetry, waxy pores, fashion-model faces or advertising lighting.

Exactly one subject standing front-facing with level shoulders, direct gaze, neutral mouth and arms hanging naturally at his sides. Show all hair, complete head, shoulders, both arms, torso and waist DOWN TO HIP LEVEL. Do not show additional people, body doubles, captions, labels, player numbers or a collage.

Plain PURE WHITE short-sleeved REGULAR-FIT football jersey, unbranded, comfortably draped with subtle folds; never skin-tight or body-sculpting. No logo, sponsor, number, text, color trim, props or accessories.

Source image vertical 3:4 with native genuine TRANSPARENT RGBA PNG alpha; background outside the subject must be fully alpha=0, NOT a printed checkerboard, gray backdrop or artificial transparency pattern. Clean naturally antialiased edges without chromatic halo or matte contamination.

Maintain the described facial details precisely. One person only. Photographic realism, natural soft lighting, direct camera gaze, full hair and head through hip level. No typography, graphics or collage.
