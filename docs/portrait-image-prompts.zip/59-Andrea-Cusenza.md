Create exactly one NEW original ultra-photorealistic studio media-day portrait of a fictional young male footballer, approximately 21–25 years old. This is a new image generated solely from the following written visual description.

IMMUTABLE CANONICAL FACIAL DESCRIPTION: faithfully reproduce EACH listed feature, especially skin complexion, hair color, hair texture, hair length and exact compatible haircut:
FACE SHAPE: long oval face. CHEEKS: slightly hollow cheeks. FOREHEAD: wide forehead.
EYES: blue-gray eyes, ordinary almond-shaped eyes, ordinary eye spacing. BROWS: slightly unequal eyebrows.
NOSE: gently broad nasal bridge, natural rounded nose tip. JAW: wide softly rounded jawline. CHIN: slightly recessed chin.
MOUTH: slightly broader mouth, slightly fuller lips. EARS: slightly prominent ears.
COMPLEXION: light warm complexion. FACIAL HAIR: sparse facial hair.
HAIR: short length; black color; slightly wavy texture; ordinary short wavy haircut; rather dense hair; ordinary hairline.
SKIN: subtle non-retouched pores; few tiny blemishes.

PHYSIQUE: lean-fit; a lean compact torso and lightly trained but unsculpted arms. This must remain consistent with the frozen initial strength/speed/agility body class, not position or stereotypes. Stamina cannot inflate muscle definition. Ordinary human body softness is welcome; no bodybuilder build, etched abs, sculpted deltoids or oversized biceps.

Look like an ordinary real young male, approximately 21–25 years old, chosen for footballing ability rather than looks. Preserve natural asymmetry, non-idealized facial proportions, visible natural skin texture and small imperfections. No beauty retouching, glamorous styling, perfect symmetry, waxy pores, fashion-model faces or advertising lighting.

Exactly one subject standing front-facing with level shoulders, direct gaze, neutral mouth and arms hanging naturally at his sides. Show all hair, complete head, shoulders, both arms, torso and waist DOWN TO HIP LEVEL. Do not show additional people, body doubles, captions, labels, player numbers or a collage.

Plain PURE WHITE short-sleeved REGULAR-FIT football jersey, unbranded, comfortably draped with subtle folds; never skin-tight or body-sculpting. No logo, sponsor, number, text, color trim, props or accessories.

Source image vertical 3:4 with native genuine TRANSPARENT RGBA PNG alpha; background outside the subject must be fully alpha=0, NOT a printed checkerboard, gray backdrop or artificial transparency pattern. Clean naturally antialiased edges without chromatic halo or matte contamination.

Maintain the described facial details precisely. One person only. Photographic realism, natural soft lighting, direct camera gaze, full hair and head through hip level. No typography, graphics or collage.
