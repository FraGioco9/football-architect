# FOOTBALL ARCHITECT — NEW INDIVIDUAL PORTRAIT CHAT

This entire chat is ONLY for 60 — Enrico Pasi.
Metadata for QA (NEVER render as text in the image):
Player ID: 60
Player name: Enrico Pasi
Immutable appearance version: player-portrait-v4.1
Immutable appearance fingerprint: 1a64070f9f1578a8
Frozen physical class: sturdy
Prompt export version: single-player-chat-v1

Start by generating EXACTLY ONE original PNG portrait of this one player.
No collage, no contact sheet, no other footballer, no caption and no second image in the same generation.
Follow the exact canonical appearance below. Do not copy an old published portrait, previous generated face or another person.
Treat nationality and name as bookkeeping metadata only; facial features come exclusively from the canonical snapshot.

===== FULL VERSIONED IMAGE PROMPT — APPLY VERBATIM =====
CHATGPT IMAGE GENERATION V4.1 — EXACTLY ONE INDIVIDUAL IMAGE FOR THIS PLAYER ONLY.

The immutable identity below is the ONLY allowed facial reference; ignore all prior players and their images. Never reuse a previous face or produce a collage.

--- CANONICAL V4.1 PROMPT (VERBATIM) ---

Create an ultra-photorealistic media-day cutout portrait of EXACTLY ONE fictional adult male footballer.

Primary nationality: Italy. These are citizenship details, not ethnicity, facial identity or skin-tone constraints. Never infer ancestry, age or appearance from names, citizenship, club or football position.

IMMUTABLE CANONICAL FACIAL DESCRIPTION: faithfully reproduce EACH listed feature, especially skin complexion, hair color, hair texture, hair length and exact compatible haircut:
FACE SHAPE: narrow oval face. CHEEKS: asymmetrically full cheeks. FOREHEAD: shorter forehead.
EYES: brown eyes, narrow-set eyelid shape, ordinary eye spacing. BROWS: ordinary straight eyebrows.
NOSE: straight unremarkable nasal bridge, narrower nose tip. JAW: subtly asymmetric jawline. CHIN: subtle cleft in the chin.
MOUTH: ordinary relaxed mouth width, rather thin lips. EARS: ordinary ears.
COMPLEXION: medium golden-brown complexion. FACIAL HAIR: patchy short beard.
HAIR: short length; medium brown color; wavy texture; slightly tousled practical crop; ordinary natural density; ordinary hairline.
SKIN: natural visible skin texture and pores; no conspicuous facial mark.

PHYSIQUE: sturdy; robust shoulders with ordinary soft muscular definition. This must remain consistent with the frozen initial strength/speed/agility body class, not position or stereotypes. Stamina cannot inflate muscle definition. Ordinary human body softness is welcome; no bodybuilder build, etched abs, sculpted deltoids or oversized biceps.

Look like an ordinary real adult male, chosen for footballing ability rather than looks. Preserve natural asymmetry, non-idealized facial proportions, visible natural skin texture and small imperfections. No beauty retouching, glamorous styling, perfect symmetry, waxy pores, fashion-model faces or advertising lighting.

Exactly one subject standing front-facing with level shoulders, direct gaze, neutral mouth and arms hanging naturally at his sides. Show all hair, complete head, shoulders, both arms, torso and waist DOWN TO HIP LEVEL. Do not show additional people, body doubles, captions, labels, player numbers or a collage.

Plain PURE WHITE short-sleeved REGULAR-FIT football jersey, unbranded, comfortably draped with subtle folds; never skin-tight or body-sculpting. No logo, sponsor, number, text, color trim, props or accessories.

Source image vertical 3:4 with native genuine TRANSPARENT RGBA PNG alpha; background outside the subject must be fully alpha=0, NOT a printed checkerboard, gray backdrop or artificial transparency pattern. Clean naturally antialiased edges without chromatic halo or matte contamination.

Final downstream 320 x 362 WebP QA framing target: 3-8 px significant upper alpha margin; review 0-12 px only when every strand of hair remains visible. Keep at least 20 px transparent side room and horizontal silhouette centered; do not shrink the face or crop hair to meet pixel numbers. The numbers apply to the derivative, not to the original 3:4 PNG.

IMPORTANT: match this SINGLE frozen identity rather than any earlier portrait or example person. Never substitute the same generic photogenic face across multiple IDs. Keep the chosen hair shape compatible with texture and length. Adult male is the only age wording. No automatic publication or owner-approval claim.

--- END CANONICAL V4.1 PROMPT ---

EXECUTION GUARDS: Generate a single fictional adult male, never an age-specific subject or an idealized model. One image invocation only; do not batch or automatically generate a second.

Use a genuinely transparent RGBA PNG cutout, not an opaque checkerboard. Follow all binding traits, especially complexion, hair texture, hair length, hairstyle and ordinary facial proportions.

The output is a local candidate until real PNG alpha, final WebP geometry, trait consistency and visual QA are evaluated. Complete QA before considering another generation. PASS or PASS_WITH_NOTE may be locally accepted; FAIL must not be published. Publishing and D1 updates require separate authorization.
===== END IMAGE PROMPT =====

AFTER THIS SINGLE IMAGE:
- Complete the technical QA of the ACTUAL PNG bytes if tools are available: real RGBA alpha, no painted checkerboard, complete hair/anatomy, source vertical 3:4. If exact pixel data are unavailable, explicitly report technical QA as NOT VERIFIED; do not invent PASS or margin numbers.
- Make a centered 320x362 transparent WebP QA derivative without altering the face, and check decoded alpha, 3–8 px top-margin target (0–12 px only with intact hair), >=20 px transparent side room, centering, and colored edge fringes. Never claim this was measured unless the actual pixels were inspected.
- Perform strict visual identity QA: exactly the specified complexion, face geometry, eyes, haircut texture/length/color, natural mouth/nose/ears, realistic body type, ordinary non-model face, regular-fit plain-white jersey. Wrong person is always FAIL even when dimensions are valid.
- Report PASS, PASS CON NOTA or FAIL with the exact deviations. When BOTH technical and visual QA pass, automatically accept the candidate (retain notes) but DO NOT publish or update a database.
- If FAIL, record why before considering a retry. Any retry must be a NEW single image, never an additional image in this same invocation, and must receive its own complete QA. Stop repeated wrong-person contamination.
- Preserve the original generated PNG. Do not overwrite existing approved WebPs, update D1, merge a PR, or deploy. GitHub asset publication requires separate explicit authorisation.

The only permitted age wording is: adult male. Produce exactly one portrait first.
