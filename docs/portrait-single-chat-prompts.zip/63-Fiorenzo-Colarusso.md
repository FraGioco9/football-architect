# FOOTBALL ARCHITECT — NEW INDIVIDUAL PORTRAIT CHAT

[$github](app://connector_76869538009648d5b282a4bb21c3d157) [$cloudflare](app://asdk_app_6abc2a9552748191b465859a06e90da3)

This entire chat is ONLY for 63 — Fiorenzo Colarusso.
Metadata for QA (NEVER render as text in the image):
Player ID: 63
Player name: Fiorenzo Colarusso
Immutable appearance version: player-portrait-v4.1
Immutable appearance fingerprint: c580a3526d483791
Frozen physical class: average-fit
Prompt export version: single-player-chat-v3

PERMITTED CONNECTORS AND IMAGE ENGINE — STRICT:
- Use the connected GitHub plugin to read V4.1 instructions on PR #648 and to record QA in issue #646 when permitted. The old approved WebP may be checked for existence/metadata ONLY; it is NEVER a creation input or facial/pose reference. Never commit/publish/rewrite images or merge without separate approval.
- Use the connected Cloudflare plugin ONLY for read-only verification against DEV D1 database football-architect-dev of this player ID and frozen initial physical attributes, and optionally Preview context. NEVER access or modify Production. Never write to any D1 table, snapshot, asset_key or status on the strength of this prompt.
- ONLY ChatGPT built-in ImageGen ORIGINAL TEXT-TO-IMAGE CREATION may generate the portrait. Do not invoke image editing, remix, restoration, or image-to-image. NEVER use Canva, the Canva plugin, Canva designs, templates, external design services or third-party generators.
- GitHub/Cloudflare are data and QA connectors, NOT rendering tools. If either connector cannot be accessed, say so and mark that verification NOT VERIFIED. The complete frozen V4.1 identity below remains binding; do not fabricate a connector result or derive a new identity from current/evolved stats.

IMAGE CREATION MODE — ORIGINAL TEXT-TO-IMAGE, ZERO INPUT IMAGES:
- Generate a NEW image from the written canonical description ONLY, starting from scratch. This is NOT an edit, variation, remix, restoration, or alteration of a photo.
- An uploaded reference image is NOT REQUIRED. Do not ask the user to upload, choose, locate or identify a reference photo for composition, framing, pose, appearance or any other reason.
- Call only the original text-to-image generation capability, without image IDs, existing portraits, attachments, input_image, masks, URLs or reference-image parameters. The existing approved WebP is NEVER the image input.
- If the tool is edit-only, requests a source/image target, or offers no original text-to-image generation, STOP and report GENERATION_UNAVAILABLE / NO CANDIDATE. Do not call an image-edit operation, request an upload, fabricate an output or claim any image QA passed.

Start by generating EXACTLY ONE original PNG portrait of this one player.
No collage, no contact sheet, no other footballer, no caption and no second image in the same generation.
Follow the exact canonical appearance below. Do not copy an old published portrait, previous generated face or another person.
Treat nationality and name as bookkeeping metadata only; facial features come exclusively from the canonical snapshot.

===== FULL VERSIONED IMAGE PROMPT — APPLY VERBATIM =====
CHATGPT IMAGE GENERATION V4.1 — EXACTLY ONE INDIVIDUAL IMAGE FOR THIS PLAYER ONLY.

ORIGINAL TEXT-TO-IMAGE CREATION ONLY: create from scratch without an input photo, image ID, existing portrait, mask or image reference. This is not editing, variation or restoration.

The immutable written identity below is the ONLY authority for facial appearance. Never use an earlier player or existing image as a visual reference. Never produce a collage.

--- CANONICAL V4.1 PROMPT (VERBATIM) ---

Create an ultra-photorealistic media-day cutout portrait of EXACTLY ONE fictional adult male footballer.

Primary nationality: Italy. These are citizenship details, not ethnicity, facial identity or skin-tone constraints. Never infer ancestry, age or appearance from names, citizenship, club or football position.

IMMUTABLE CANONICAL FACIAL DESCRIPTION: faithfully reproduce EACH listed feature, especially skin complexion, hair color, hair texture, hair length and exact compatible haircut:
FACE SHAPE: soft square face. CHEEKS: asymmetrically full cheeks. FOREHEAD: ordinary forehead height.
EYES: dark brown eyes, softly downturned outer corners, slightly wide-set eyes. BROWS: softly arched eyebrows.
NOSE: subtle asymmetry in the nasal bridge, moderately broad nose tip. JAW: narrow ordinary jawline. CHIN: slightly asymmetric chin.
MOUTH: one lip corner subtly lower, rather thin lips. EARS: slightly asymmetrical ear size.
COMPLEXION: medium golden-brown complexion. FACIAL HAIR: faint uneven stubble.
HAIR: medium length; dark brown color; wavy texture; medium wavy unstyled haircut; ordinary natural density; slightly higher temples.
SKIN: natural visible skin texture and pores; no conspicuous facial mark.

PHYSIQUE: average-fit; average shoulders and arms without visible muscle sculpting. This must remain consistent with the frozen initial strength/speed/agility body class, not position or stereotypes. Stamina cannot inflate muscle definition. Ordinary human body softness is welcome; no bodybuilder build, etched abs, sculpted deltoids or oversized biceps.

Look like an ordinary real adult male, chosen for footballing ability rather than looks. Preserve natural asymmetry, non-idealized facial proportions, visible natural skin texture and small imperfections. No beauty retouching, glamorous styling, perfect symmetry, waxy pores, fashion-model faces or advertising lighting.

Exactly one subject standing front-facing with level shoulders, direct gaze, neutral mouth and arms hanging naturally at his sides. Show all hair, complete head, shoulders, both arms, torso and waist DOWN TO HIP LEVEL. Do not show additional people, body doubles, captions, labels, player numbers or a collage.

Plain PURE WHITE short-sleeved REGULAR-FIT football jersey, unbranded, comfortably draped with subtle folds; never skin-tight or body-sculpting. No logo, sponsor, number, text, color trim, props or accessories.

Source image vertical 3:4 with native genuine TRANSPARENT RGBA PNG alpha; background outside the subject must be fully alpha=0, NOT a printed checkerboard, gray backdrop or artificial transparency pattern. Clean naturally antialiased edges without chromatic halo or matte contamination.

Final downstream 320 x 362 WebP QA framing target: 3-8 px significant upper alpha margin; review 0-12 px only when every strand of hair remains visible. Keep at least 20 px transparent side room and horizontal silhouette centered; do not shrink the face or crop hair to meet pixel numbers. The numbers apply to the derivative, not to the original 3:4 PNG.

IMPORTANT: match this SINGLE frozen identity rather than any earlier portrait or example person. Never substitute the same generic photogenic face across multiple IDs. Keep the chosen hair shape compatible with texture and length. Adult male is the only age wording. No automatic publication or owner-approval claim.

--- END CANONICAL V4.1 PROMPT ---

EXECUTION GUARDS: Generate a single fictional adult male, never an age-specific subject or an idealized model. One image invocation only; do not batch or automatically generate a second.

Use a genuinely transparent RGBA PNG cutout, not an opaque checkerboard. Follow all binding traits, especially complexion, hair texture, hair length, hairstyle and ordinary facial proportions.

The output is a local candidate until real PNG alpha, final WebP geometry, trait consistency and visual QA are evaluated. Complete QA before considering another generation. PASS or PASS_WITH_NOTE may be locally accepted; FAIL must not be published. Publishing and D1 updates require separate authorization.
===== END IMAGE PROMPT =====

AFTER THIS SINGLE IMAGE:
- Complete the technical QA of the ACTUAL PNG bytes if tools are available: real RGBA alpha, no painted checkerboard, complete hair/anatomy, source vertical 3:4. If exact pixel data are unavailable, explicitly report technical QA as NOT VERIFIED; do not invent PASS or margin numbers.
- Make a centered 320x362 transparent WebP QA derivative without altering the face, and check decoded alpha, 3–8 px top-margin target (0–12 px only with intact hair), >=20 px transparent side room, centering, and colored edge fringes. Never claim this was measured unless the actual pixels were inspected.
- Perform strict visual identity QA: exactly the specified complexion, face geometry, eyes, haircut texture/length/color, natural mouth/nose/ears, realistic body type, ordinary non-model face, regular-fit plain-white jersey. Wrong person is always FAIL even when dimensions are valid.
- Report PASS, PASS CON NOTA or FAIL with the exact deviations. When BOTH technical and visual QA pass, automatically accept the candidate (retain notes) but DO NOT publish or update a database.
- If FAIL, record why before considering a retry. Any retry must be a NEW single image, never an additional image in this same invocation, and must receive its own complete QA. Stop repeated wrong-person contamination.
- Use the connected GitHub plugin (not Canva) for QA traceability: reference issue #646, the player ID, immutable V4.1 fingerprint, original image generation identifier when available, SHA-256 for actual files when verifiable, technical/visual PASS/PASS CON NOTA/FAIL and deviations. If writing a QA comment is not possible, provide the report for the user to copy; do not claim a comment was posted.
- Use the connected Cloudflare plugin for read-only DEV confirmation when available. No status or asset_key changes, and never use a Production database for these candidate portraits.
- Preserve the original generated PNG. Do not overwrite existing approved WebPs, update D1, merge a PR, or deploy. GitHub asset publication requires separate explicit authorisation.

The only permitted age wording is: adult male. Produce exactly one portrait first.

